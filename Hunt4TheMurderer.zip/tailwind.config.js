/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./Hunt4TheMurderer/**/*.{html,js}"],
    theme: {
      extend: {},
    },
    plugins: [],
  }