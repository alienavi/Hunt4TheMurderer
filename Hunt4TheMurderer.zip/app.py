from Hunt4TheMurderer import create_app
app, _ = create_app() 